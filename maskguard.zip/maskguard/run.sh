#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
echo "Buka http://127.0.0.1:8000 di browser"
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
