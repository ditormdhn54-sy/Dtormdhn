Folder model (OPSIONAL). Aplikasi tetap berjalan tanpa file di sini (mode demo).

1) Klasifikasi masker (Keras, MobileNetV2 hasil transfer learning)
   - Letakkan: models/mask_detector.h5   (atau mask_detector.keras)
   - Input 224x224 RGB, preprocessing MobileNetV2 (piksel dinormalisasi ke [-1, 1])
   - Output 2 kelas dengan urutan [pakai_masker, tanpa_masker]
   - Butuh paket tambahan:  pip install tensorflow

2) Prediksi usia & jenis kelamin (OpenCV DNN, model Levi & Hassner)
   Letakkan 4 berkas ini:
   - deploy_age.prototxt      + age_net.caffemodel
   - deploy_gender.prototxt   + gender_net.caffemodel
   Tidak butuh paket tambahan (sudah ada di OpenCV).
