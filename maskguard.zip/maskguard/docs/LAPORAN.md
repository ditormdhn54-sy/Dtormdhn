# Dokumen Laporan Demo – MaskGuard

## 1. Deskripsi Aplikasi Prototype
- **Nama aplikasi:** MaskGuard
- **Permasalahan:** Pemeriksaan kepatuhan masker secara manual lambat dan tidak tercatat. Pengelola ruang (kampus, klinik, kantor) butuh cara cepat memeriksa foto dan memantau tingkat kepatuhan.
- **Target pengguna:** Petugas keamanan atau pengelola fasilitas yang memantau kepatuhan masker.
- **Fitur utama:** unggah foto atau ambil dari kamera; deteksi wajah dengan kotak penanda; klasifikasi pakai/tanpa masker beserta tingkat keyakinan; riwayat pemindaian; dashboard statistik kepatuhan; penanganan error dan tampilan kosong.

## 2. Arsitektur Sistem
- **Frontend:** HTML, CSS, JavaScript murni (canvas untuk menggambar kotak deteksi, MediaDevices API untuk kamera).
- **Backend:** Python FastAPI + Uvicorn (REST API).
- **Database:** SQLite (`data/app.db`), tabel `scans` berisi waktu, nama berkas, jumlah wajah, jumlah masker, jumlah tanpa masker, durasi. Gambar tidak disimpan.
- **Integrasi API:** frontend memanggil `/api/predict` (multipart), `/api/history`, `/api/stats`, `/api/health` lewat `fetch`.
- **Komponen AI/ML:** modul `inference.py` dengan tiga tahap: deteksi wajah (Haar Cascade OpenCV), klasifikasi masker (MobileNetV2 Keras bila `models/mask_detector.h5` ada, jika tidak memakai heuristik warna kulit), serta prediksi usia dan jenis kelamin (OpenCV DNN, aktif bila model Caffe dipasang).

## 3. Dokumentasi Screenshot (keterangan siap pakai)
1. **Halaman utama:** dashboard dengan empat angka statistik, area unggah foto, dan riwayat kosong.
2. **Proses input:** foto sudah dipilih dan tampil pada kanvas, tombol Analisis foto aktif.
3. **Loading/inferensi:** lapisan "Menjalankan inferensi…" saat gambar diproses server.
4. **Hasil prediksi:** kotak hijau/merah pada wajah, ringkasan hasil, dan baris baru di riwayat.
5. **Error handling:** pesan merah saat berkas bukan gambar, terlalu besar, atau server tidak terhubung.
6. **Empty state:** tampilan "Riwayat masih kosong" dan "Belum ada hasil" saat belum ada data.

## 4. Penjelasan Implementasi AI/ML
- **Metode:** deteksi wajah Haar Cascade; klasifikasi masker CNN MobileNetV2 (transfer learning) atau heuristik warna kulit pada mode demo.
- **Dataset:** (isi sesuai yang kamu pakai) mis. dataset masker dari Kaggle untuk melatih MobileNetV2. Mode demo tidak memakai dataset pelatihan.
- **Preprocessing:** koreksi orientasi EXIF, konversi RGB, pengecilan gambar untuk deteksi (maks 1000 px), equalizeHist; untuk MobileNetV2: crop wajah, resize 224x224, normalisasi [-1, 1].
- **Training/penggunaan model:** (isi) mis. MobileNetV2 pretrained ImageNet, kepala klasifikasi 2 kelas, dilatih lalu disimpan sebagai `mask_detector.h5`; server hanya melakukan inferensi.
- **Cara menghasilkan output:** gambar masuk, wajah dideteksi, tiap crop wajah diklasifikasi, hasil dikembalikan sebagai JSON (kotak, label, confidence, usia, jenis kelamin) lalu digambar di kanvas.
- **Evaluasi:** (isi) mis. accuracy, precision, recall pada data uji. Mode demo belum dievaluasi secara formal dan peka terhadap pencahayaan serta masker berwarna kulit.
