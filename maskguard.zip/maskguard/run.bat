@echo off
cd /d "%~dp0"
if not exist .venv (
    python -m venv .venv
)
call .venv\Scripts\activate
python -m pip install -r requirements.txt
echo.
echo Buka http://127.0.0.1:8000 di browser
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
