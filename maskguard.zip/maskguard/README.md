# MaskGuard – Pemantau Kepatuhan Masker

Aplikasi web prototype: unggah foto atau ambil dari kamera, sistem mendeteksi wajah, menentukan
pakai masker atau tidak, lalu mencatat hasilnya ke riwayat dan dashboard statistik.

## Menjalankan (Windows)
1. Pasang Python 3.10 atau lebih baru (centang "Add Python to PATH").
2. Klik dua kali `run.bat` (pertama kali akan memasang paket, butuh internet).
3. Buka http://127.0.0.1:8000

Linux/macOS: `./run.sh`. Manual:
```
python -m venv .venv
.venv\Scripts\activate          (Linux/macOS: source .venv/bin/activate)
pip install -r requirements.txt
python -m uvicorn backend.main:app --port 8000
```
Dokumentasi API otomatis: http://127.0.0.1:8000/docs

## Struktur
```
backend/main.py        API FastAPI (predict, history, stats, health)
backend/inference.py   Deteksi wajah, klasifikasi masker, usia & jenis kelamin
backend/db.py          Riwayat pemindaian (SQLite)
frontend/              index.html, style.css, app.js
models/                (opsional) model Keras / Caffe, lihat models/README.txt
data/                  berkas database app.db dibuat otomatis
docs/LAPORAN.md        Draf isi Laporan Demo
```

## Endpoint
| Metode | Path | Fungsi |
|---|---|---|
| GET | /api/health | Status server dan mesin yang aktif |
| POST | /api/predict | Unggah gambar (field `file`), kembalikan hasil per wajah |
| GET | /api/history?limit=20 | Riwayat pemindaian |
| GET | /api/stats | Total foto, wajah, masker, tingkat kepatuhan |
| DELETE | /api/history | Hapus riwayat |

## Mode demo vs model terpasang
Tanpa file di `models/`, klasifikasi masker memakai heuristik warna kulit (mode demo) dan
usia/jenis kelamin tidak ditampilkan. Setelah file model diletakkan sesuai `models/README.txt`,
mesin otomatis memakainya saat server dijalankan ulang.

## Pemecahan masalah
- Port 8000 terpakai: ganti `--port 8001`.
- Kamera tidak muncul: izinkan kamera di browser. Kamera hanya jalan di localhost atau HTTPS.
- Wajah tidak terdeteksi: pakai foto menghadap depan, terang, wajah tidak terlalu kecil.
