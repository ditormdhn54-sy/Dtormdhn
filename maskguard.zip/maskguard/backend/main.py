"""MaskGuard API (FastAPI). Jalankan:  python -m uvicorn backend.main:app --port 8000"""
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from . import db
from .inference import ImageError, engine

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("maskguard")

MAX_BYTES = 5 * 1024 * 1024  # 5 MB
FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init_db()
    yield


app = FastAPI(title="MaskGuard API", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/api/health")
def health():
    return {"status": "ok", "engine": engine.info()}


@app.post("/api/predict")
def predict(file: UploadFile = File(...)):
    ctype = (file.content_type or "").lower()
    if ctype and not ctype.startswith("image/") and ctype != "application/octet-stream":
        raise HTTPException(status_code=415, detail="Format tidak didukung. Unggah berkas gambar (JPG, PNG, WEBP).")

    data = file.file.read(MAX_BYTES + 1)
    if not data:
        raise HTTPException(status_code=400, detail="Berkas kosong.")
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=413, detail="Ukuran gambar melebihi 5 MB.")

    try:
        result = engine.analyze(data)
    except ImageError as exc:
        raise HTTPException(status_code=exc.status, detail=exc.message)
    except Exception:  # noqa: BLE001
        log.exception("Inferensi gagal")
        raise HTTPException(status_code=500, detail="Terjadi kesalahan saat inferensi. Coba gambar lain.")

    name = (file.filename or "gambar").strip() or "gambar"
    summary = result["summary"]
    result["id"] = db.add_scan(name, summary["total"], summary["mask"], summary["no_mask"], result["duration_ms"])
    result["filename"] = name[:120]
    return result


@app.get("/api/history")
def history(limit: int = Query(20, ge=1, le=100)):
    return db.list_scans(limit)


@app.get("/api/stats")
def stats():
    return db.stats()


@app.delete("/api/history")
def clear_history():
    db.clear()
    return {"status": "cleared"}


app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
