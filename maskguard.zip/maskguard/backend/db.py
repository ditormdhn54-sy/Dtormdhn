"""Penyimpanan riwayat pemindaian (SQLite, pustaka standar Python)."""
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "app.db"


def _conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with closing(_conn()) as conn, conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scans (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at  TEXT    NOT NULL,
                filename    TEXT    NOT NULL,
                faces       INTEGER NOT NULL,
                mask        INTEGER NOT NULL,
                no_mask     INTEGER NOT NULL,
                duration_ms INTEGER NOT NULL
            )
            """
        )


def add_scan(filename: str, faces: int, mask: int, no_mask: int, duration_ms: int) -> int:
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with closing(_conn()) as conn, conn:
        cur = conn.execute(
            "INSERT INTO scans (created_at, filename, faces, mask, no_mask, duration_ms) VALUES (?,?,?,?,?,?)",
            (now, filename[:120], faces, mask, no_mask, duration_ms),
        )
        return int(cur.lastrowid)


def list_scans(limit: int = 20) -> list:
    with closing(_conn()) as conn:
        rows = conn.execute("SELECT * FROM scans ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def stats() -> dict:
    with closing(_conn()) as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS scans, COALESCE(SUM(faces),0) AS faces, "
            "COALESCE(SUM(mask),0) AS mask, COALESCE(SUM(no_mask),0) AS no_mask FROM scans"
        ).fetchone()
    data = dict(row)
    data["compliance"] = round(data["mask"] * 100 / data["faces"], 1) if data["faces"] else None
    return data


def clear() -> None:
    with closing(_conn()) as conn, conn:
        conn.execute("DELETE FROM scans")
