"""Mesin inferensi MaskGuard: deteksi wajah, klasifikasi masker, prediksi usia & jenis kelamin.

Komponen berlapis supaya aplikasi SELALU bisa jalan:
  - Deteksi wajah  : Haar Cascade bawaan OpenCV (tanpa unduhan).
  - Klasifikasi masker:
        * jika models/mask_detector.h5 ada  -> MobileNetV2 (Keras)
        * jika tidak                         -> heuristik warna kulit (mode demo)
  - Usia & jenis kelamin: aktif hanya jika 4 berkas model Caffe ada di folder models/.
"""
import io
import logging
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageOps

log = logging.getLogger("maskguard.inference")

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"
MAX_FACES = 30
DETECT_MAX_SIDE = 1000
MASK_INDEX = 0  # urutan output model Keras: [pakai_masker, tanpa_masker]

AGE_BUCKETS = ["0-2", "4-6", "8-12", "15-20", "25-32", "38-43", "48-53", "60+"]
GENDERS = ["Laki-laki", "Perempuan"]
CAFFE_MEAN = (78.4263377603, 87.7689143744, 114.895847746)

Image.MAX_IMAGE_PIXELS = 40_000_000


class ImageError(Exception):
    """Kesalahan input gambar yang aman ditampilkan ke pengguna."""

    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status


def decode_image(data: bytes) -> np.ndarray:
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
        img = ImageOps.exif_transpose(img).convert("RGB")
    except Exception:
        raise ImageError(
            "Berkas tidak bisa dibaca sebagai gambar. Gunakan JPG, PNG, atau WEBP yang tidak rusak."
        )
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)


def _skin_ratio(bgr: np.ndarray) -> float:
    if bgr is None or bgr.size == 0:
        return 0.0
    ycrcb = cv2.cvtColor(bgr, cv2.COLOR_BGR2YCrCb)
    skin = cv2.inRange(ycrcb, (0, 133, 77), (255, 173, 127))
    return float(skin.mean() / 255.0)


class Engine:
    def __init__(self) -> None:
        base = cv2.data.haarcascades
        self.detector = cv2.CascadeClassifier(base + "haarcascade_frontalface_default.xml")
        self.detector_alt = cv2.CascadeClassifier(base + "haarcascade_frontalface_alt2.xml")
        if self.detector.empty():
            raise RuntimeError("Haar Cascade wajah gagal dimuat. Pasang ulang opencv-python-headless.")
        if self.detector_alt.empty():
            self.detector_alt = None

        self.keras_model = None
        self.age_net = None
        self.gender_net = None
        self._load_keras()
        self._load_caffe()

    # ------------------------------------------------------------------ loader
    def _load_keras(self) -> None:
        for name in ("mask_detector.h5", "mask_detector.keras"):
            path = MODEL_DIR / name
            if not path.exists():
                continue
            try:
                import tensorflow as tf  # impor berat, hanya jika model ada

                self.keras_model = tf.keras.models.load_model(str(path), compile=False)
                log.info("Model masker Keras dimuat: %s", path.name)
                return
            except Exception as exc:  # noqa: BLE001
                log.warning("Model masker %s gagal dimuat (%s). Memakai mode demo.", path.name, exc)

    def _load_caffe(self) -> None:
        files = [
            MODEL_DIR / "deploy_age.prototxt",
            MODEL_DIR / "age_net.caffemodel",
            MODEL_DIR / "deploy_gender.prototxt",
            MODEL_DIR / "gender_net.caffemodel",
        ]
        if not all(f.exists() for f in files):
            return
        try:
            self.age_net = cv2.dnn.readNet(str(files[1]), str(files[0]))
            self.gender_net = cv2.dnn.readNet(str(files[3]), str(files[2]))
            log.info("Model usia & jenis kelamin dimuat.")
        except Exception as exc:  # noqa: BLE001
            self.age_net = self.gender_net = None
            log.warning("Model usia/jenis kelamin gagal dimuat (%s).", exc)

    def info(self) -> dict:
        return {
            "detector": "Haar Cascade",
            "mask": "MobileNetV2 (Keras)" if self.keras_model is not None else "Heuristik warna kulit (mode demo)",
            "mask_is_demo": self.keras_model is None,
            "age_gender": "Caffe DNN (Levi & Hassner)" if self.age_net is not None else None,
        }

    # --------------------------------------------------------------- deteksi
    def detect_faces(self, img: np.ndarray) -> list:
        h, w = img.shape[:2]
        scale = min(1.0, DETECT_MAX_SIDE / max(h, w))
        small = cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA) if scale < 1 else img
        gray = cv2.equalizeHist(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY))
        min_side = max(40, int(min(small.shape[:2]) * 0.06))

        faces = self.detector.detectMultiScale(
            gray, scaleFactor=1.1, minNeighbors=5, minSize=(min_side, min_side)
        )
        if len(faces) == 0 and self.detector_alt is not None:
            faces = self.detector_alt.detectMultiScale(
                gray, scaleFactor=1.1, minNeighbors=4, minSize=(min_side, min_side)
            )

        boxes = []
        for (x, y, fw, fh) in faces:
            x0 = max(0, int(x / scale))
            y0 = max(0, int(y / scale))
            x1 = min(w, int((x + fw) / scale))
            y1 = min(h, int((y + fh) / scale))
            if x1 - x0 > 10 and y1 - y0 > 10:
                boxes.append((x0, y0, x1 - x0, y1 - y0))
        boxes.sort(key=lambda b: b[0])
        return boxes[:MAX_FACES]

    # -------------------------------------------------------------- masker
    def _mask_heuristic(self, face: np.ndarray):
        fh, fw = face.shape[:2]
        upper = face[int(fh * 0.10): int(fh * 0.40), int(fw * 0.15): int(fw * 0.85)]
        lower = face[int(fh * 0.58): int(fh * 0.92), int(fw * 0.20): int(fw * 0.80)]
        u, l = _skin_ratio(upper), _skin_ratio(lower)

        if u >= 0.20:
            ratio = l / (u + 1e-6)
            has_mask = ratio < 0.45
            if has_mask:
                conf = 0.60 + 0.35 * (1.0 - ratio / 0.45)
            else:
                conf = 0.60 + 0.35 * min(1.0, (ratio - 0.45) / 0.55)
        else:  # pencahayaan ekstrem, bagian atas wajah tidak terbaca sebagai kulit
            has_mask = l < 0.20
            conf = 0.55
        return bool(has_mask), float(min(0.95, max(0.5, conf)))

    def _mask_keras(self, face: np.ndarray):
        rgb = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
        rgb = cv2.resize(rgb, (224, 224)).astype("float32") / 127.5 - 1.0
        pred = np.asarray(self.keras_model.predict(rgb[None, ...], verbose=0))[0].ravel()
        if pred.size != 2:
            raise ValueError("Model masker harus memiliki 2 output [pakai_masker, tanpa_masker].")
        mask_p = float(pred[MASK_INDEX])
        no_mask_p = float(pred[1 - MASK_INDEX])
        total = mask_p + no_mask_p
        if total > 0:
            mask_p, no_mask_p = mask_p / total, no_mask_p / total
        has_mask = mask_p >= no_mask_p
        return has_mask, max(mask_p, no_mask_p)

    def classify_mask(self, face: np.ndarray):
        if self.keras_model is not None:
            try:
                return self._mask_keras(face)
            except Exception as exc:  # noqa: BLE001
                log.warning("Inferensi Keras gagal (%s). Beralih ke heuristik.", exc)
                self.keras_model = None
        return self._mask_heuristic(face)

    # ------------------------------------------------------- usia & gender
    def age_gender(self, img: np.ndarray, box: tuple):
        if self.age_net is None or self.gender_net is None:
            return None, None
        x, y, w, h = box
        pad = int(0.2 * max(w, h))
        H, W = img.shape[:2]
        crop = img[max(0, y - pad): min(H, y + h + pad), max(0, x - pad): min(W, x + w + pad)]
        if crop.size == 0:
            return None, None
        try:
            blob = cv2.dnn.blobFromImage(crop, 1.0, (227, 227), CAFFE_MEAN, swapRB=False)
            self.gender_net.setInput(blob)
            gender = GENDERS[int(self.gender_net.forward()[0].argmax())]
            self.age_net.setInput(blob)
            age = AGE_BUCKETS[int(self.age_net.forward()[0].argmax())]
            return age, gender
        except Exception as exc:  # noqa: BLE001
            log.warning("Prediksi usia/jenis kelamin gagal: %s", exc)
            return None, None

    # --------------------------------------------------------------- utama
    def analyze(self, data: bytes) -> dict:
        t0 = time.perf_counter()
        img = decode_image(data)
        H, W = img.shape[:2]

        faces_out = []
        for box in self.detect_faces(img):
            x, y, w, h = box
            has_mask, conf = self.classify_mask(img[y: y + h, x: x + w])
            age, gender = self.age_gender(img, box)
            faces_out.append(
                {
                    "box": {"x": x, "y": y, "w": w, "h": h},
                    "has_mask": has_mask,
                    "label": "Pakai masker" if has_mask else "Tanpa masker",
                    "confidence": round(conf, 3),
                    "age": age,
                    "gender": gender,
                }
            )

        masked = sum(1 for f in faces_out if f["has_mask"])
        return {
            "width": W,
            "height": H,
            "faces": faces_out,
            "summary": {"total": len(faces_out), "mask": masked, "no_mask": len(faces_out) - masked},
            "duration_ms": int((time.perf_counter() - t0) * 1000),
            "engine": self.info(),
        }


engine = Engine()
