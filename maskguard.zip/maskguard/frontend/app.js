"use strict";

const MAX_BYTES = 5 * 1024 * 1024;
const $ = (id) => document.getElementById(id);

const el = {
  badge: $("engineBadge"), alert: $("alert"),
  statScans: $("statScans"), statFaces: $("statFaces"), statMask: $("statMask"), statRate: $("statRate"),
  btnPick: $("btnPick"), btnCamera: $("btnCamera"), btnSnap: $("btnSnap"),
  btnAnalyze: $("btnAnalyze"), btnReset: $("btnReset"), fileInput: $("fileInput"),
  drop: $("drop"), viewport: $("viewport"), canvas: $("canvas"), video: $("video"), loader: $("loader"),
  resultEmpty: $("resultEmpty"), resultBody: $("resultBody"), resultHead: $("resultHead"),
  faceList: $("faceList"), resultNote: $("resultNote"),
  historyEmpty: $("historyEmpty"), historyTable: $("historyTable"), historyBody: $("historyBody"),
  btnClear: $("btnClear"),
};

const state = { blob: null, name: "", image: null, stream: null, busy: false };

/* ---------------------------------------------------------------- util */
function showAlert(message, kind) {
  el.alert.textContent = message;
  el.alert.className = "alert" + (kind === "info" ? " info" : "");
}
function hideAlert() { el.alert.className = "alert hidden"; el.alert.textContent = ""; }

function make(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

async function api(path, options) {
  let res;
  try {
    res = await fetch(path, options);
  } catch (err) {
    throw new Error("Tidak dapat terhubung ke server. Pastikan backend sudah berjalan (python -m uvicorn backend.main:app).");
  }
  let body = null;
  try { body = await res.json(); } catch (err) { /* respons bukan JSON */ }
  if (!res.ok) {
    const detail = body && typeof body.detail === "string" ? body.detail : "Server mengembalikan status " + res.status + ".";
    throw new Error(detail);
  }
  return body;
}

function formatTime(iso) {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}

/* ------------------------------------------------------------ UI state */
function refreshButtons() {
  const camOn = !!state.stream;
  el.btnAnalyze.disabled = !state.blob || state.busy || camOn;
  el.btnSnap.classList.toggle("hidden", !camOn);
  el.btnReset.classList.toggle("hidden", !state.blob && !camOn);
  el.btnPick.disabled = state.busy;
  el.btnCamera.disabled = state.busy || camOn;
}

function setLoading(on) {
  state.busy = on;
  el.loader.classList.toggle("hidden", !on);
  refreshButtons();
}

function showStage(mode) { // "drop" | "image" | "camera"
  el.drop.classList.toggle("hidden", mode !== "drop");
  el.viewport.classList.toggle("hidden", mode === "drop");
  el.canvas.classList.toggle("hidden", mode === "camera");
  el.video.classList.toggle("hidden", mode !== "camera");
}

function resetResult() {
  el.resultBody.classList.add("hidden");
  el.resultEmpty.classList.remove("hidden");
  el.faceList.replaceChildren();
  el.resultNote.textContent = "";
}

/* ------------------------------------------------------------- gambar */
function setImage(blob, name) {
  hideAlert();
  if (!blob || !blob.type || !blob.type.startsWith("image/")) {
    showAlert("Format tidak didukung. Pilih berkas gambar (JPG, PNG, atau WEBP).");
    return;
  }
  if (blob.size > MAX_BYTES) {
    showAlert("Ukuran gambar " + (blob.size / 1048576).toFixed(1) + " MB melebihi batas 5 MB. Perkecil gambar lalu coba lagi.");
    return;
  }
  const url = URL.createObjectURL(blob);
  const img = new Image();
  img.onload = () => {
    URL.revokeObjectURL(url);
    stopCamera();
    state.blob = blob;
    state.name = name || "gambar";
    state.image = img;
    drawBase();
    showStage("image");
    resetResult();
    refreshButtons();
  };
  img.onerror = () => {
    URL.revokeObjectURL(url);
    showAlert("Gambar tidak bisa dibuka. Berkas mungkin rusak atau formatnya (misalnya HEIC) tidak didukung browser.");
  };
  img.src = url;
}

function drawBase() {
  const img = state.image;
  el.canvas.width = img.naturalWidth;
  el.canvas.height = img.naturalHeight;
  el.canvas.getContext("2d").drawImage(img, 0, 0);
}

function drawResult(result) {
  drawBase();
  const ctx = el.canvas.getContext("2d");
  const line = Math.max(3, Math.round(el.canvas.width / 220));
  const font = Math.max(14, Math.round(el.canvas.width / 48));
  ctx.lineWidth = line;
  ctx.font = "600 " + font + "px sans-serif";
  ctx.textBaseline = "top";

  result.faces.forEach((f) => {
    const { x, y, w, h } = f.box;
    const color = f.has_mask ? "#2fbf7f" : "#e5533a";
    ctx.strokeStyle = color;
    ctx.strokeRect(x, y, w, h);

    const text = f.label + " " + Math.round(f.confidence * 100) + "%";
    const pad = Math.round(font * 0.35);
    const boxH = font + pad * 2;
    const boxW = ctx.measureText(text).width + pad * 2;
    const ty = y - boxH >= 0 ? y - boxH : y;
    ctx.fillStyle = color;
    ctx.fillRect(x, ty, boxW, boxH);
    ctx.fillStyle = "#06201a";
    ctx.fillText(text, x + pad, ty + pad);
  });
}

/* -------------------------------------------------------------- kamera */
async function openCamera() {
  hideAlert();
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showAlert("Browser ini tidak mendukung kamera. Gunakan Pilih foto sebagai gantinya.");
    return;
  }
  try {
    state.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
  } catch (err) {
    state.stream = null;
    const denied = err && (err.name === "NotAllowedError" || err.name === "SecurityError");
    showAlert(denied
      ? "Akses kamera ditolak. Izinkan kamera pada pengaturan browser, atau gunakan Pilih foto."
      : "Kamera tidak ditemukan atau sedang dipakai aplikasi lain.");
    refreshButtons();
    return;
  }
  el.video.srcObject = state.stream;
  try { await el.video.play(); } catch (err) { /* autoplay dibatasi, abaikan */ }
  showStage("camera");
  refreshButtons();
}

function stopCamera() {
  if (state.stream) {
    state.stream.getTracks().forEach((t) => t.stop());
    state.stream = null;
  }
  el.video.srcObject = null;
}

function snapPhoto() {
  const v = el.video;
  if (!v.videoWidth) { showAlert("Kamera belum siap. Tunggu sebentar lalu coba lagi.", "info"); return; }
  const tmp = document.createElement("canvas");
  tmp.width = v.videoWidth;
  tmp.height = v.videoHeight;
  tmp.getContext("2d").drawImage(v, 0, 0);
  tmp.toBlob((blob) => {
    if (!blob) { showAlert("Gagal mengambil foto dari kamera."); return; }
    setImage(blob, "kamera.jpg");
  }, "image/jpeg", 0.92);
}

function resetAll() {
  stopCamera();
  state.blob = null; state.image = null; state.name = "";
  el.fileInput.value = "";
  hideAlert();
  showStage("drop");
  resetResult();
  refreshButtons();
}

/* -------------------------------------------------------------- analisis */
async function analyze() {
  if (!state.blob || state.busy) return;
  hideAlert();
  setLoading(true);
  try {
    const form = new FormData();
    form.append("file", state.blob, state.name);
    const result = await api("/api/predict", { method: "POST", body: form });
    drawResult(result);
    renderResult(result);
    await Promise.all([loadHistory(), loadStats()]);
  } catch (err) {
    showAlert(err.message);
  } finally {
    setLoading(false);
  }
}

function renderResult(result) {
  el.resultEmpty.classList.add("hidden");
  el.resultBody.classList.remove("hidden");
  el.faceList.replaceChildren();

  const s = result.summary;
  el.resultHead.replaceChildren();
  if (s.total === 0) {
    el.resultHead.className = "result-head warn";
    el.resultHead.append("Wajah tidak ditemukan", make("small", "", "Gunakan foto yang menghadap depan, cukup terang, dan wajahnya tidak terlalu kecil."));
  } else if (s.no_mask > 0) {
    el.resultHead.className = "result-head bad";
    el.resultHead.append(s.no_mask + " dari " + s.total + " wajah tanpa masker", make("small", "", s.mask + " wajah sudah memakai masker."));
  } else {
    el.resultHead.className = "result-head ok";
    el.resultHead.append("Semua wajah memakai masker", make("small", "", s.total + " wajah terdeteksi."));
  }

  result.faces.forEach((f, i) => {
    const li = make("li");
    const left = make("div");
    left.append(make("div", "", "Wajah " + (i + 1)));
    const detail = [];
    if (f.gender) detail.push(f.gender);
    if (f.age) detail.push("usia " + f.age);
    left.append(make("div", "meta", detail.length ? detail.join(", ") : "Usia dan jenis kelamin belum tersedia"));
    li.append(left, make("span", "tag " + (f.has_mask ? "ok" : "bad"), f.label + " " + Math.round(f.confidence * 100) + "%"));
    el.faceList.append(li);
  });

  const parts = ["Deteksi: " + result.engine.detector, "Masker: " + result.engine.mask, result.duration_ms + " ms"];
  let note = parts.join(" | ");
  if (result.engine.mask_is_demo) note += ". Mode demo: pasang model di folder models/ untuk hasil lebih akurat.";
  el.resultNote.textContent = note;
}

/* ------------------------------------------------------ riwayat & statistik */
async function loadHistory() {
  try {
    const rows = await api("/api/history?limit=20");
    el.historyBody.replaceChildren();
    const has = rows.length > 0;
    el.historyEmpty.classList.toggle("hidden", has);
    el.historyTable.classList.toggle("hidden", !has);
    rows.forEach((r) => {
      const tr = make("tr");
      tr.append(make("td", "", formatTime(r.created_at)));
      const name = make("td", "name", r.filename);
      name.title = r.filename;
      tr.append(name, make("td", "r", String(r.faces)), make("td", "r", String(r.mask)), make("td", "r", String(r.no_mask)));
      el.historyBody.append(tr);
    });
  } catch (err) { /* status ditampilkan oleh badge */ }
}

async function loadStats() {
  try {
    const s = await api("/api/stats");
    el.statScans.textContent = s.scans;
    el.statFaces.textContent = s.faces;
    el.statMask.textContent = s.mask;
    el.statRate.textContent = s.compliance === null ? "—" : s.compliance + "%";
  } catch (err) { /* abaikan */ }
}

async function loadHealth() {
  try {
    const h = await api("/api/health");
    const demo = h.engine.mask_is_demo;
    el.badge.className = "badge " + (demo ? "demo" : "ok");
    el.badge.textContent = demo ? "Server aktif, mode demo" : "Server aktif, model terpasang";
  } catch (err) {
    el.badge.className = "badge off";
    el.badge.textContent = "Server tidak terhubung";
    showAlert(err.message);
  }
}

async function clearHistory() {
  if (!window.confirm("Hapus seluruh riwayat pemindaian?")) return;
  try {
    await api("/api/history", { method: "DELETE" });
    await Promise.all([loadHistory(), loadStats()]);
  } catch (err) {
    showAlert(err.message);
  }
}

/* --------------------------------------------------------------- event */
el.btnPick.addEventListener("click", () => el.fileInput.click());
el.drop.addEventListener("click", () => el.fileInput.click());
el.drop.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") { e.preventDefault(); el.fileInput.click(); }
});
el.fileInput.addEventListener("change", () => {
  const f = el.fileInput.files && el.fileInput.files[0];
  if (f) setImage(f, f.name);
  el.fileInput.value = "";
});
["dragenter", "dragover"].forEach((t) => el.drop.addEventListener(t, (e) => { e.preventDefault(); el.drop.classList.add("over"); }));
["dragleave", "drop"].forEach((t) => el.drop.addEventListener(t, (e) => { e.preventDefault(); el.drop.classList.remove("over"); }));
el.drop.addEventListener("drop", (e) => {
  const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (f) setImage(f, f.name);
});
el.btnCamera.addEventListener("click", openCamera);
el.btnSnap.addEventListener("click", snapPhoto);
el.btnAnalyze.addEventListener("click", analyze);
el.btnReset.addEventListener("click", resetAll);
el.btnClear.addEventListener("click", clearHistory);
window.addEventListener("beforeunload", stopCamera);

refreshButtons();
loadHealth();
loadHistory();
loadStats();
